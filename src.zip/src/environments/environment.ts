export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000', // tu API Node
  useStreaming: true
};

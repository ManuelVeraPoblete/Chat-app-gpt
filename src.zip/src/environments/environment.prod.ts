export const environment = {
  production: true,
  apiBaseUrl: 'https://tu-dominio-api.cl',
  useStreaming: true
};

/***************************************************************************************************
 * Polyfills
 *
 * Zone JS is required by default for Angular itself.
 * This file is loaded before the application.
 **************************************************************************************************/

import 'zone.js'; // ✅ Requerido por Angular cuando NO estás en modo zoneless
